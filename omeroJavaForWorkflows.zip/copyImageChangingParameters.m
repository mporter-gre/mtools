function [newImageId] = copyImageChangingParameters(imageId, parameters, pixels)

sizeX = pixels.getSizeX.getValue;
sizeY = pixels.getSizeY.getValue;
sizeT = pixels.getSizeT.getValue;
sizeZ = pixels.getSizeZ.getValue;
channelList = java.util.ArrayList;
for thisChannel = 1:length(parameters.channelList)
    channelList.add(int32(thisChannel))
end
imageName = java.lang.String(parameters.imageName);

[client, session, gateway] = blitzkriegBop;
newImageId = gateway.copyImage(imageId, sizeX, sizeY, sizeZ, sizeT, channelList, imageName);

end