function plane = getPlaneFromImageId(pixelsId, z, c, t, gateway)

pixels = gateway.getPixels(pixelsId);
rawPlane = gateway.getPlane(pixelsId, z, c , t);
plane2D = omerojava.util.GatewayUtils.getPlane2D(pixels, rawPlane);
plane = plane2D.getPixelsArrayAsDouble(1);

end