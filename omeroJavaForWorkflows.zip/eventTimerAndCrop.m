function [roiIdx roishapeIdx] = eventTimerAndCrop(filepath, filename, username, password, fileNum, numFiles, conditionNum, numConditions)
%Let the user know what's going on...
scrsz = get(0,'ScreenSize');
fig1 = figure('Name','Processing...','NumberTitle','off','MenuBar','none','Position',[(scrsz(3)/2)-150 (scrsz(4)/2)-80 300 80]);
conditionText = uicontrol(fig1, 'Style', 'text', 'String', ['Condition ', num2str(conditionNum), ' of ' num2str(numConditions)], 'Position', [25 60 250 15]);
fileText = uicontrol(fig1, 'Style', 'text', 'String', ['ROI file ', num2str(fileNum), ' of ' num2str(numFiles)], 'Position', [25 35 250 15]);

drawnow;
%[filename filepath] = uigetfile('*.xml');
%Process the ROI file for cropping the images and passing the ROI's back to
%selectROIFiles.m
[roiIdx roishapeIdx] = readROIs([filepath filename]);
[client, session, gateway] = gatewayConnect(username, password);
[pixelsId, imageName] = getPixIdFromROIFile(filename);
pixelsId = str2double(pixelsId);
pixels = gateway.getPixels(pixelsId);
imageId = pixels.getImage.getId.getValue;
maxX = pixels.getSizeX.getValue;
maxY = pixels.getSizeY.getValue;
fullZ = pixels.getSizeZ.getValue;
fullT = pixels.getSizeT.getValue;
numC = pixels.getSizeC.getValue;

%Find the linear indices of the ROI's position on each frame (x,y,t,z).
%Use these indices to map intensity pixels from the original image to the
%new "Events" image. Also gather the 'deltaT' info for the first and last
%frames.
numROI = length(roiIdx);
ROIText = uicontrol(fig1, 'Style', 'text', 'Position', [25 10 250 15]);
for thisROI = 1:numROI
    set(ROIText, 'String', ['ROI ', num2str(thisROI), ' of ' num2str(numROI)]);
    drawnow;
    numZ(thisROI) = length(unique(roishapeIdx{thisROI}.Z));
    numT(thisROI) = length(unique(roishapeIdx{thisROI}.T));
    for thisT = 1:numT(thisROI)
        for thisZ = 1:numZ(thisROI)
            indices{thisROI}{thisT}{thisZ} = [];
        end
    end

    actualZ{thisROI} = unique(roishapeIdx{thisROI}.Z); %indices of the Z and T of the original image that this ROI points to.
    actualT{thisROI} = unique(roishapeIdx{thisROI}.T);
    planeInfoForPixels = gateway.findAllByQuery(['select info from PlaneInfo as info where pixels.id = ', num2str(pixelsId), ' and info.theT = ' num2str(roishapeIdx{thisROI}.T(1)), ' and theZ = ', num2str(roishapeIdx{thisROI}.Z(1)), ' and theC = 0']);
    firstDeltaT = planeInfoForPixels.get(0).getDeltaT.getValue;
    planeInfoForPixels = gateway.findAllByQuery(['select info from PlaneInfo as info where pixels.id = ', num2str(pixelsId), ' and info.theT = ' num2str(roishapeIdx{thisROI}.T(end)), ' and theZ = ', num2str(roishapeIdx{thisROI}.Z(1)), ' and theC = 0']);
    lastDeltaT = planeInfoForPixels.get(0).getDeltaT.getValue;
    roishapeIdx{thisROI}.deltaT = lastDeltaT - firstDeltaT;
    roishapeIdx{thisROI}.name = [imageName '_event_' num2str(thisROI)];
    roishapeIdx{thisROI}.origName = imageName;
    
    for thisT = 1:numT(thisROI)
        for thisZ = 1:numZ(thisROI)
            X = roishapeIdx{thisROI}.X(thisT*thisZ)+1;    %svg entry in xml file indexes from (0, 0) instead of (1, 1), so +1
            Y = roishapeIdx{thisROI}.Y(thisT*thisZ)+1;
            width = roishapeIdx{thisROI}.Width(thisT*thisZ);
            height = roishapeIdx{thisROI}.Height(thisT*thisZ);
            for col = 1:width
                posX = col+X-1;
                if posX > maxX  %If the ROI was drawn to extend off the image, set the crop to the edge of the image only.
                    posX = maxX;
                end
                for row = 1:height
                    posY = row+Y-1;
                    if posY > maxY
                        posY = maxY;
                    end
                    indices{thisROI}{thisT}{thisZ} = [indices{thisROI}{thisT}{thisZ} sub2ind([maxY maxX],posY, posX)];
                end
            end
        end
    end
end

%Create the new Image on the server so we can upload planes to it.
channelLabels = getChannelLabelsFromPixels(session, pixels);
for thisChannel = 1:numC
    parameters.channelList = channelLabels{thisChannel};
end
parameters.channelList(end+1) = 0;
parameters.imageName = [imageName, '_events'];
[newImageId] = copyImageChangingParameters(imageId, parameters, pixels);
newImage = gateway.getImage(newImageId);
newImage.setName(omero.rtypes.rstring(parameters.imageName));
gateway.saveObject(newImage);
newPixels = gateway.getPixelsFromImage(newImageId);
newPixelsId = newPixels.get(0).getId.getValue;

%Make the full image from the ROI patches and send it to the server each
%completed T at a time.
set(ROIText, 'String', 'Sending images to server...');
drawnow;
for thisT = 1:fullT
    for thisZ = 1:fullZ
        for thisC = 1:numC+1
            newPlane = zeros(maxY, maxX);
            labelPlane = zeros(maxY, maxX);
            for thisROI = 1:numROI
                if any(actualT{thisROI}(:) == thisT-1)
                    if any(actualZ{thisROI}(:) == thisZ-1)
                        ROIZ = find(actualZ{thisROI}== thisZ-1);
                        ROIT = find(actualT{thisROI}== thisT-1);
                        if thisC > numC  %Make the channel to number these events on the image itself.
                            ROIText = num2str(thisROI);
                            lenLabel = length(ROIText);
                            spacer = 0;
                            labelX = roishapeIdx{thisROI}.X(ROIZ*ROIT)+1;
                            labelY = roishapeIdx{thisROI}.Y(ROIZ*ROIT)+1;
                            for thisLabel = 1:lenLabel
                                labelPlane = numberOverlay(labelPlane, labelX+spacer, labelY, str2double(ROIText(thisLabel)));
                                spacer = spacer + 7;
                            end
                            newPlane = labelPlane;
                        else  %Copy the intensity patch from the original image to the new plane;
                            thisPlane = getPlaneFromPixelsId(pixelsId, thisZ-1, thisC-1, thisT-1, gateway);
                            newPlane(indices{thisROI}{ROIT}{ROIZ}) = thisPlane(indices{thisROI}{ROIT}{ROIZ});
                        end
                    end
                end
            end
            planeAsBytes = omerojava.util.GatewayUtils.convertClientToServer(newPixels.get(0), newPlane');
            gateway.uploadPlane(newPixelsId, thisZ-1, thisC-1, thisT-1, planeAsBytes);
        end
    end
end

%Now make the channel to number these events on the image itself

%Set the new image's start and end display values the same as the original.
%Start by getting the start and end values for each channel
renderingEngine = session.createRenderingEngine;
renderingEngine.lookupPixels(pixelsId);
renderingEngine.lookupRenderingDef(pixelsId);
renderingEngine.load();
for thisC = 1:numC
    channelStart(thisC) = renderingEngine.getChannelWindowStart(thisC-1);
    channelEnd(thisC) = renderingEngine.getChannelWindowEnd(thisC-1);
end
renderingEngine.close();

%Now load the rendersettings for the new image and apply the settings.
renderingEngine = session.createRenderingEngine;
renderingEngine.lookupPixels(newPixelsId);
renderingEngine.resetDefaults;
renderingEngine.lookupRenderingDef(newPixelsId);
renderingEngine.load();
for thisC = 1:numC
    renderingEngine.setActive(thisC-1,1);
    renderingEngine.setChannelWindow(thisC-1, channelStart(thisC), channelEnd(thisC));
end
pixServiceDescription = session.getPixelsService.retrievePixDescription(newPixelsId).getChannel(thisC).getLogicalChannel();
pixServiceDescription.setName(omero.rtypes.rstring('Events'));
iUpdate = session.getUpdateService();
iUpdate.saveObject(pixServiceDescription);
rendEng.setRGBA(thisC,255,255,255,200); %Set the label channel to grey, alpha 200;
renderingEngine.saveCurrentSettings;
renderingEngine.close();


%Link the new image into the same dataset as the original image.
thisImageLinks = gateway.findAllByQuery(['select link from DatasetImageLink as link where link.child.id = ', num2str(imageId)]);
imageLinksIter = thisImageLinks.iterator;
thisIter = 1;
while imageLinksIter.hasNext
    imageLinks(thisIter) = imageLinksIter.next.getParent.getId.getValue;
    thisIter = thisIter + 1;
end
sortedLinks = sort(imageLinks);

aDataset = gateway.getDataset(sortedLinks(1),0);
aDataset.unload;
newImage.unload;
newLink = omero.model.DatasetImageLinkI();
newLink.link(aDataset, newImage);
gateway.saveObject(newLink);

close(fig1);

end