function [roiIdx roishapeIdx] = volumeIntensityMeasure(filepath, filename, username, password, fileNum, numFiles, conditionNum, numConditions)
%Let the user know what's going on, position it in the centre of the screen...
scrsz = get(0,'ScreenSize');
fig1 = figure('Name','Processing...','NumberTitle','off','MenuBar','none','Position',[(scrsz(3)/2)-150 (scrsz(4)/2)-180 300 80]);
conditionText = uicontrol(fig1, 'Style', 'text', 'String', ['Condition ', num2str(conditionNum), ' of ' num2str(numConditions)], 'Position', [25 60 250 15]);
fileText = uicontrol(fig1, 'Style', 'text', 'String', ['ROI file ', num2str(fileNum), ' of ' num2str(numFiles)], 'Position', [25 35 250 15]);

drawnow;
%[filename filepath] = uigetfile('*.xml');
%Process the ROI file for cropping the images and passing the ROI's back to
%selectROIFiles.m
[roiIdx roishapeIdx] = readROIs([filepath filename]);
[client, session, gateway] = gatewayConnect(username, password);
[pixelsId, imageName] = getPixIdFromROIFile(filename);
pixelsId = str2double(pixelsId);
pixels = gateway.getPixels(pixelsId);
imageId = pixels.getImage.getId.getValue;
maxX = pixels.getSizeX.getValue;
maxY = pixels.getSizeY.getValue;

segChannel = getSegChannel(session, pixels);

%, '|2.', channelLabel{2}, '|3. ', channelLabel{3}, '|4. ', channelLabel{4}
%Get planes for each ROIShape listed, grouped by ROI, then copy the ROI
%patch to a new image and upload it to the server. Also get the deltaT via
%query for the first and last roishape T and Z.
numROI = length(roiIdx);
for thisROI = 1:numROI
roishapeIdx{thisROI}.name = [imageName '_mask'];
roishapeIdx{thisROI}.origName = imageName;
end
ROIText = uicontrol(fig1, 'Style', 'text', 'Position', [25 10 250 15]);

patches = cutPatchesFromROI(roishapeIdx, numROI, segChannel, pixels, gateway);

%Piece together a mask image the same size as the original image, and send
%it back to the server. Use segmented patches, also calculated here.

[roishapeIdx, fullMaskImg] = ROISegmentMeasureAndMask(roishapeIdx, patches, pixels, ROIText);

%Use only a single channel and time point for the fullMaskImage upload.
for thisChannel = 1
    parameters.channelList = thisChannel;
end
parameters.imageName = roishapeIdx{1}.name;
newImageId = copyImageChangingParameters(imageId, parameters, pixels);
newImage = gateway.getImage(newImageId);
newImage.setName(omero.rtypes.rstring(parameters.imageName));
gateway.saveObject(newImage);
newPixels = gateway.getPixelsFromImage(newImageId);
newPixelsId = newPixels.get(0).getId.getValue;

for thisZ = 1:length(fullMaskImg(1,1,:))
    planeAsBytes = omerojava.util.GatewayUtils.convertClientToServer(newPixels.get(0), fullMaskImg(:,:,thisZ)');
    gateway.uploadPlane(newPixelsId, thisZ-1, 0, 0, planeAsBytes);
end

thisImageLinks = gateway.findAllByQuery(['select link from DatasetImageLink as link where link.child.id = ', num2str(imageId)]);
imageLinksIter = thisImageLinks.iterator;
thisIter = 1;
while imageLinksIter.hasNext
    imageLinks(thisIter) = imageLinksIter.next.getParent.getId.getValue;
    thisIter = thisIter + 1;
end
sortedLinks = sort(imageLinks);

aDataset = gateway.getDataset(sortedLinks(1),0);
aDataset.unload;
newImage.unload;
newLink = omero.model.DatasetImageLinkI();
newLink.link(aDataset, newImage);
gateway.saveObject(newLink);

clear('patches');
clear('fullMaskImg');
close(fig1);

end