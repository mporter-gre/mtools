function maskStack = seg3D(cube)
%Pass in a Z-stack (cube) and perform Otsu thresholding in all 3 dimensions
%to segment out the object. If there is only 1 Z-section then seg2D.m is 
%used instead. Pass it back as a stack of binary masks.

numY = length(cube(:,1,1));
numX = length(cube(1,:,1));
numZ = length(cube(1,1,:));

if numZ == 1
    maskStack = seg2D(cube);
else
    for thisZ = 1:numZ
        patchScZ = cube(:,:,thisZ)./max2(cube(:,:,thisZ));
        patch_01Z = patchScZ.*255;
        imgThreshZ = otsu(patch_01Z)/255;
        patchMaskZ(:,:,thisZ) = im2bw(patchScZ, imgThreshZ);
    end
    for thisX = 1:numX
        patchScX = squeeze(cube(:,thisX,:)./max2(cube(:,thisX,:)));
        patch_01X = patchScX.*255;
        imgThreshX = otsu(patch_01X)/255;
        patchMaskX(:,:,thisX) = im2bw(patchScX, imgThreshX);
    end
    for thisY = 1:numY
        patchScY = squeeze(cube(thisY,:,:)./max2(cube(thisY,:,:)));
        patch_01Y = patchScY.*255;
        imgThreshY = otsu(patch_01Y)/255;
        patchMaskY(:,:,thisY) = im2bw(patchScY, imgThreshY);
    end
    maskStack = zeros(numY,numX,numZ);
    for thisZ = 1:numZ
        for thisX = 1:numX
            for thisY = 1:numY
                if patchMaskY(thisX,thisZ,thisY) == 1 && patchMaskX(thisY,thisZ,thisX) == 1 && patchMaskZ(thisY,thisX,thisZ) == 1
                    maskStack(thisY,thisX,thisZ) = 1;
                end
            end
        end
    end
clear('patchMaskX');
clear('patchMaskY');
clear('patchMaskZ');
end

end