function plane = getPlaneFromImageId(id, z, c, t, gateway)

pixels = gateway.getPixelsFromImage(id);
pixelsId = pixels.get(0).getId().getValue();
rawPlane = gateway.getPlane(pixelsId, z, c , t);
plane2D = omerojava.util.GatewayUtils.getPlane2D(pixels.get(0), rawPlane);
plane = plane2D.getPixelsArrayAsDouble(1);

end