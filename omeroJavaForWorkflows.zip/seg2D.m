function mask = seg2D(plane)
%Pass in a 2D image (plane) and perform Otsu thresholding to segment out 
%the object. Pass it back as a binary mask.

patchSc = plane./max2(plane);
patch_01 = patchSc.*255;
imgThresh = otsu(patch_01)/255;
mask = im2bw(patchSc, imgThresh);

end