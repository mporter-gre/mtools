function [pixId imageName] = getPixIdFromROIFile(filename)

[imageName, remain] = strtok(filename, '.');
partName = 'hi';
sysUser = getenv('username');
sysOs = getenv('os');

%On Windows systems
if strcmp(sysOs, 'Windows_NT');
    mapPath = ['C:\Documents and Settings\', sysUser, '\omero\roiFileMap.xml'];
end

mapStruct = xml2struct(mapPath);

for lvl1 = 1:length(mapStruct.children)
    for lvl2 = 1:length(mapStruct.children(lvl1).children(1).children)
        [nameProc, partName] = strtok(mapStruct.children(lvl1).children(1).children(lvl2).children(1).attributes(1).value, '\');
        while ~isempty(partName)
            [nameProc, partName] = strtok(partName, '\');
        end
        [imageNameFromStruct, remain] = strtok(nameProc, '.');
        if strcmp(imageNameFromStruct, imageName)
            pixId = mapStruct.children(lvl1).children(1).children(lvl2).attributes(1).value;
        end
    end
end


end