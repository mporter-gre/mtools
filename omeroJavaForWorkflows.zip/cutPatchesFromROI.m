function patches = cutPatchesFromROI(roishapeIdx, numROI, channels, pixels, gateway)

for thisROI = 1:numROI
    numZ(thisROI) = length(unique(roishapeIdx{thisROI}.Z));
    numT(thisROI) = length(unique(roishapeIdx{thisROI}.T));
    thisPatch = 1;
    X = roishapeIdx{thisROI}.X(1)+1;    %svg entry in xml file indexes from (0, 0) instead of (1, 1), so +1
    Y = roishapeIdx{thisROI}.Y(1)+1;
    width = roishapeIdx{thisROI}.Width(1);
    height = roishapeIdx{thisROI}.Height(1);
    maxX = pixels.getSizeX.getValue;
    maxY = pixels.getSizeY.getValue;
    pixelsId = pixels.getId.getValue;

    for thisZ = 1:numZ(thisROI)
        for thisT = 1
            for thisC = channels
                %for thisC = 1:numChannels
                thisPlane = getPlaneFromPixelsId(pixelsId, roishapeIdx{thisROI}.Z(thisZ), thisC-1, roishapeIdx{thisROI}.T(thisT), gateway);
                patch(:,:, thisPatch) = zeros(height,width);
                for col = 1:width
                    posX = col+X-1;
                    if posX > maxX  %If the ROI was drawn to extend off the image, set the crop to the edge of the image only.
                        posX = maxX;
                    end
                    for row = 1:height
                        posY = row+Y-1;
                        if posY > maxY
                            posY = maxY;
                        end
                        patch(row, col, thisPatch) = thisPlane(posY, posX);
                    end
                end
                thisPatch = thisPatch + 1;
            end
        end
    end
    patches{thisROI} = patch;
    patch = [];
end
end